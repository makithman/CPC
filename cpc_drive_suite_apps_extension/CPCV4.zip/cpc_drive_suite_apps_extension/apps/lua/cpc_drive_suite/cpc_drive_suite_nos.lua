-- CPC Drive Suite - sequential gear/NOS runtime

return function(__CPC)
  __CPC.nosStatus = 'NOS ready'
  __CPC.nosStatusKind = 'idle'
  __CPC.nosActive = false
  __CPC.nosPulseRemaining = 0
  __CPC.nosTargetGear = 0
  __CPC.nosButton = ac.ControlButton
    and ac.ControlButton('cpc.drive.suite/NOS boost', { hold = true })
    or nil

  local function buttonPressed()
    local nosButton = __CPC.nosButton
    local dumpButton = __CPC.launchDumpButton
    local nosPressed = nosButton and nosButton.pressed and nosButton:pressed() or false
    local dumpPressed = dumpButton and dumpButton.pressed and dumpButton:pressed() or false
    return nosPressed or dumpPressed
  end

  function __CPC.resetNOS()
    __CPC.nosActive = false
    __CPC.nosPulseRemaining = 0
    __CPC.nosTargetGear = 0
    __CPC.nosStatus = 'NOS ready'
    __CPC.nosStatusKind = 'idle'
    if __CPC.controlsOverride then
      __CPC.controlsOverride.requestedGearIndex = 0
    end
    if ac.setExtraTorque then ac.setExtraTorque(0) end
  end

  function __CPC.updateNOS(dt, car)
    if not car then
      __CPC.resetNOS()
      __CPC.nosStatus = 'Waiting for player car'
      return
    end

    local enabled = __CPC.settings.suiteEnabled and __CPC.settings.nosEnabled
    local throttleReady = not __CPC.settings.nosRequiresThrottle
      or (__CPC.telemetry.gas or 0) > 0.05
    local gearCount = math.floor(__CPC.Math.finiteNumber(car.gearCount, 0) + 0.5)
    local currentGear = math.floor(__CPC.Math.finiteNumber(car.gear, 0) + 0.5)
    __CPC.nosPulseRemaining = math.max(0, __CPC.nosPulseRemaining - math.max(dt or 0, 0))
    if enabled and buttonPressed() and throttleReady and currentGear >= 1
        and currentGear < gearCount then
      __CPC.nosTargetGear = currentGear + 1
      __CPC.nosPulseRemaining = math.max(__CPC.settings.nosShiftDuration or 0.28, 0.05)
    end
    local active = enabled and __CPC.nosPulseRemaining > 0 and __CPC.nosTargetGear > 0

    if active then
      __CPC.nosActive = true
      __CPC.nosStatus = string.format('NOS SHIFT - gear %d -> %d', currentGear, __CPC.nosTargetGear)
      __CPC.nosStatusKind = 'action'
      if __CPC.controlsOverride then
        __CPC.controlsOverride.requestedGearIndex = __CPC.nosTargetGear
      end
      if ac.setExtraTorque then
        ac.setExtraTorque(math.max(0, __CPC.settings.nosExtraTorque))
      end
      return
    end

    if __CPC.controlsOverride then
      __CPC.controlsOverride.requestedGearIndex = 0
    end
    if ac.setExtraTorque then ac.setExtraTorque(0) end
    __CPC.nosActive = false
    if not enabled then
      __CPC.nosStatus = __CPC.settings.suiteEnabled and 'NOS disabled' or 'Suite paused'
      __CPC.nosStatusKind = 'idle'
    elseif gearCount < 2 then
      __CPC.nosStatus = 'No usable forward gear track'
      __CPC.nosStatusKind = 'warning'
    elseif not throttleReady then
      __CPC.nosStatus = 'Press NOS with throttle'
      __CPC.nosStatusKind = 'idle'
    elseif currentGear >= gearCount then
      __CPC.nosStatus = string.format('Top gear %d - no next gear', gearCount)
      __CPC.nosStatusKind = 'idle'
    else
      __CPC.nosStatus = string.format('Ready: gear %d -> %d', currentGear, currentGear + 1)
      __CPC.nosStatusKind = 'idle'
    end
  end
end